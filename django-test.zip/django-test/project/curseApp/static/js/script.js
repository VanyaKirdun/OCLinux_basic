let dataDir = dirs.split(' ');
let dataFile = files.split(' ');

if(isFile !== 'false'){
    alert(isFile)
}

let block = document.querySelector('.files');

let form = document.querySelector('.create__form');
let dirr = document.createElement('input');
dirr.type = 'hidden';
dirr.name = 'way';
dirr.value = way;
form.append(dirr);

let maskForm = document.querySelector('.mask__form');
let maskDirr = dirr.cloneNode(true);
maskForm.append(maskDirr);

let returnForm = document.querySelector('.return__form');
let returnDirr = dirr.cloneNode(true);
returnForm.append(returnDirr);

let renForm = document.querySelector('.rename__form');
let renDirr = dirr.cloneNode(true);
renForm.append(renDirr);


function formGener(req, way, container, icon){
    let cont = document.createElement('div');
    cont.classList.add("files__forms");
    let form = document.createElement('form');
    form.action = "/cd/";
    form.method = "post";
    form.classList.add("files__way");
    
    let input = document.createElement('input');
    input.type = 'submit';
    input.name = 'file';
    input.value = req;

    let dirr = document.createElement('input');
    dirr.type = 'hidden';
    dirr.name = 'way';
    dirr.value = way;

    var hidInp = document.createElement('input');
    hidInp.type = 'hidden';
    hidInp.name = 'csrfmiddlewaretoken';
    hidInp.value = token;

    let delForm = document.createElement('form');
    delForm.action = "/delete/";
    delForm.method = "post";
    delForm.classList.add("files__delete");

    let delet = document.createElement('input');
    delet.type = 'image';
    delet.name = 'file';
    delet.src = deletImg;
    delet.alt = '';
    delet.value = req;
    delet.classList.add('img')

    let delDeff = hidInp.cloneNode(true);
    let dellDirr = dirr.cloneNode(true);

    form.append(hidInp, dirr, input);
    delForm.append(delDeff, dellDirr, delet)

    let imgCont = document.createElement('div');
    imgCont.classList.add('files__icons');

    let img = document.createElement('img');
    img.classList.add('img');
    img.src = icon;
    img.alt = '';

    imgCont.append(img);

    cont.append(imgCont, form, delForm);
    container.append(cont);

}

dataDir.forEach((value)=>{
    formGener(value, way, block, dirrImg);
})

dataFile.forEach((value)=>{
    formGener(value, way, block, fileImg);
})



