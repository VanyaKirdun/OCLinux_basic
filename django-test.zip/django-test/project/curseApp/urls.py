from django.urls import path
from .views import *

urlpatterns = [
    path('cd/', cd, name='cd'),
    path('create/', create, name='create'),
    path('delete/', delete, name='delete'),
    path('rename/', rename, name='rename'),
    path('maskDel/', maskDel, name='maskDel'),
    path('return/', returning, name='returning'),
    path('', home, name='home'),
]
