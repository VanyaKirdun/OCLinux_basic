from django.shortcuts import render
import json
import os, glob
import os.path
import shutil
from django.shortcuts import redirect


def home(request, dirr = '/home/vanya', isFile = 'false'):
    isFile = 'false'
    dirr = '/home/vanya'
    if not request.session.is_empty():
        dirr = request.session['dirr']
        isFile = request.session['isFile']
        request.session.flush ()

    direct = os.listdir(dirr)
    fullpaths = map(lambda name: os.path.join(dirr, name), direct)
    dirs = []
    files = []
    for file in fullpaths:
        if os.path.isdir(file): dirs.append(os.path.basename(file))
        if os.path.isfile(file): files.append(os.path.basename(file))

    dataFiles=' '.join(files)
    dataDirs=' '.join(dirs)
    return render(request, 'curseApp/home.html', {'dataFiles': dataFiles, 'dataDirs': dataDirs, 'way': dirr, 'isFile': isFile})

def cd(request):
    way = request.POST['way']
    files = way + '/' + request.POST['file']
    if (os.path.isfile(files)):
        request.session['dirr'] = way
        request.session['isFile'] = 'It`s file!'
        return redirect('home')
    else:
        request.session['dirr'] = files
        request.session['isFile'] = 'false'
        return redirect('home')

def create(request):
    way = request.POST['way']
    if 'checkbox' in request.POST:
        if not os.path.isdir(way+'/'+request.POST['file']):
            if not os.path.isfile(way+'/'+request.POST['file']):
                os.mkdir(way+'/'+request.POST['file'])
                isFile = 'false'
            else:
                isFile = request.POST['file'] + ' is exist here!'
        else:
            isFile = request.POST['file'] + ' is exist here!'
    else:
        if not os.path.isdir(way+'/'+request.POST['file']):
            if not os.path.isfile(way+'/'+request.POST['file']):
                text_file = open(way+'/'+request.POST['file'], "w")
                isFile = 'false'
            else:
                isFile = request.POST['file'] + ' is exist here!'
        else:
            isFile = request.POST['file'] + ' is exist here!'
   
    dirr = way
    request.session['dirr'] = dirr
    request.session['isFile'] = isFile
    return redirect('home')


def delete(request):
    way = request.POST['way']
    files = way + '/' + request.POST['file']
    if os.path.isdir(way+'/'+request.POST['file']):
        shutil.rmtree(files)
    else:
        os.remove(files)
    
    isFile = 'false'    
    dirr = way
    request.session['dirr'] = dirr
    request.session['isFile'] = isFile
    return redirect('home')

def rename(request):
    way = request.POST['way']
    files = way + '/' + request.POST['file']
    if os.path.exists(files):
        os.rename(files, way + '/' + request.POST['newFile'])
        isFile = 'false'
    else:
        isFile = request.POST['file'] + ' isn`t exist here!'
    
    dirr = way
    request.session['dirr'] = dirr
    request.session['isFile'] = isFile
    return redirect('home')

def maskDel(request):
    way = request.POST['way']
    files = way + '/' + request.POST['file']
    for file in glob.glob(files):
        os.remove(file)

    isFile = 'false'
    dirr = way
    request.session['dirr'] = dirr
    request.session['isFile'] = isFile
    return redirect('home')

def returning(request):
    way = request.POST['way']
    dirr = way + '/../'
    isFile = 'false'
    request.session['dirr'] = dirr
    request.session['isFile'] = isFile
    return redirect('home')


    